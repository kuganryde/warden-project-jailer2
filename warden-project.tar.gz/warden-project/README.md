# Warden: Shadow Protocol (static project)

No build step. Serve this folder over http(s); opening index.html from disk will not load the GLB files.

    npx vercel --prod        # or: npx serve .

## Assets and credits
- `assets/models/soldier.glb`: the "Soldier" character from the three.js examples (Mixamo rig and animations: Idle, Walk, Run).
  Mixamo characters and animations are free to use in projects, including commercial ones, but may not be redistributed or sold as standalone assets.
- `vendor/GLTFLoader.js`, `vendor/SkeletonUtils.js`: three.js r128 (MIT).
- Weapon models: optional, see `assets/weapons/README.md`.

If a model fails to load, the game falls back to its built-in procedural characters and guns.

## Phones and tablets
Touch controls turn on automatically on phones and iPads (Settings has Auto, Always on, Off). Landscape is required.
On iPhone or iPad use Share, then Add to Home Screen for a full-screen app. The YouTube theme track is off by default on touch devices.
